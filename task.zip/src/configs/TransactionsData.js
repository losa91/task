import React from "react";

export const transactionsTableColumns = [
  {
    title: "id",
    dataIndex: "id",
    id: "id",
  },
  {
    title: "Amount",
    dataIndex: "amount",
    id: "amount",
  },
  {
    title: "Date",
    dataIndex: "date",
    id: "date",
  },
];
